<?php $__env->startSection('content'); ?>
    <div class="py-5 hero container-fluid">
        <div class="text-center">
            <img src="<?php echo e(asset('assets/logo/logo-dark.png')); ?>" width="300px" alt="<?php echo e(__(env('APP_NAME'))); ?>">
        </div>
        <div class="text-center py-2">
            <h4 class="fw-bolder"><?php echo e(__(':downloader Video downloader', ['downloader' => $downloader_name])); ?></h4>
            <span class="text-muted"><?php echo e(__('Download :downloader Video online', ['downloader' => $downloader_name])); ?></h4>
        </div>

        <div class="downloader-wrapper">
            <div class="input-wrapper">
                <input type="text" id="download-url"
                    placeholder="<?php echo e(__('Enter :downloader video link here...', ['downloader' => $downloader_name])); ?>">
                <button id="download-btn"><i class="bi bi-download me-2"></i>
                    <?php echo e(__('Download')); ?></button>
            </div>
            <div id="download-result">

            </div>
            
            
            
        </div>

    </div>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-6 updates-wrapper">
                <div class="card">
                    <div class="card-header"><i class="bi bi-bell-fill"></i><?php echo e(__('Updates')); ?></div>
                    <div class="card-body">
                        <?php $__currentLoopData = $updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="bg-<?php echo e($loop->even ? 'blue' : 'green'); ?> update-card">
                                <strong><?php echo e($update['title']); ?></strong><?php echo e($update['description']); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6 faq-wrapper">
                <div class="card">
                    <div class="card-header"><i class="bi bi-patch-question-fill"></i>
                        <?php echo e(__('Frequently Asked Questions')); ?>

                    </div>
                    <div class="card-body">
                        <div class="accordion" id="accordionExample">
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?php echo e($loop->iteration); ?>">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse<?php echo e($loop->iteration); ?>" aria-expanded="false"
                                            aria-controls="collapse<?php echo e($loop->iteration); ?>">
                                            <?php echo e($faq['question']); ?>

                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($loop->iteration); ?>" class="accordion-collapse collapse"
                                        aria-labelledby="heading<?php echo e($loop->iteration); ?>" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <?php echo e($faq['answer']); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(["resources/js/".strtolower($downloader_name)."-downloader.js"]); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/muhammadsaad/Desktop/workspace/fiverr/burdenman/videodownloader/resources/views/welcome.blade.php ENDPATH**/ ?>