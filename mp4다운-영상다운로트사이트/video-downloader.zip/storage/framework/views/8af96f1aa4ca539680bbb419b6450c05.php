<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"
        integrity="sha256-lSjKY0/srUM9BE3dPm+c4fBo1dky2v27Gdjm2uoZaL0=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(()=>{
            $("[data-toggle='tooltip']").tooltip();
        });
    </script>
    <title><?php echo e($title ?? 'Home' . ' | ' . env('APP_NAME', 'Video Downloader')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/sass/app.scss', 'resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="antialiased">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('assets/logo/logo.png')); ?>" alt="" width="150">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <?php echo e(__('More Downloaders')); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('youtube.index')); ?>"><?php echo e(__('Youtube Downloader')); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('facebook.index')); ?>"><?php echo e(__('Facebook Downloader')); ?></a></li>
                        </ul>
                    </li>

                </ul>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-uppercase" href="#" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <img width="36" class="me-2"
                                src="<?php echo e(asset('assets/images/flags/' . App::getLocale() . '.png')); ?>"
                                alt=""><?php echo e(App::getLocale()); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item"
                                    href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>"><?php echo e(__('English (EN)')); ?></a>
                            </li>
                            <li><a class="dropdown-item"
                                    href="<?php echo e(LaravelLocalization::getLocalizedURL('es')); ?>"><?php echo e(__('Spanish (ES)')); ?></a>
                            </li>
                            <li><a class="dropdown-item"
                                    href="<?php echo e(LaravelLocalization::getLocalizedURL('zh')); ?>"><?php echo e(__('Chinese (ZH)')); ?></a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>
    <div class="container">

        
        <footer class="footer">
            <div class="fw-bolder text-center"><?php echo e(__(env('APP_NAME'))); ?></div>
            <div class="fw-bolder text-center">
                <?php echo e(__(
                    ":app_name does not host any videos on its servers. All videos that you download are hosted on Facebook's CDNs.",
                    ['app_name' => __(env('APP_NAME'))],
                )); ?>

            </div>
            <div class="fw-bolder text-center">
                <?php echo __(
                    ":app_name (formerly FBDOWN) is a Social Media Services website and is not associated by any means to Facebook or the Facebook brand and doesn't have anything to do with Meta Platforms, Inc. <a href='javascript:void(0);'>Read the full Disclaimer</a>",
                    ['app_name' => __(env('APP_NAME'))],
                ); ?>.
            </div>
        </footer>
        
    </div>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>